var Charting = MindFusion.Charting;
var Controls = MindFusion.Charting.Controls;
var Collections = MindFusion.Charting.Collections;
var Drawing = MindFusion.Charting.Drawing;
var LabelKinds = MindFusion.Charting.LabelKinds;
var ToolTip = MindFusion.Charting.ToolTip;

// create the chart
var pieChartEl = document.getElementById('pieChart');
pieChartEl.width = pieChartEl.offsetParent.clientWidth;
pieChartEl.height = pieChartEl.offsetParent.clientHeight;
var pieChart = new Controls.PieChart(pieChartEl);
pieChart.startAngle = 45;
pieChart.title = "Sales By Year";
pieChart.showDataLabels = LabelKinds.ToolTip | LabelKinds.OuterLabel;

// customize tooltips
ToolTip.verticalPadding = 4
ToolTip.horizontalPadding = 4
pieChart.showToolTips = true;

// create data for the first series
var values = new Collections.List([10, 7, 6, 8, 6, 12, 8, 4, 7, 3]);

var series = new Charting.PieSeries(values, null, [10, 7, 6, 8, 6, 12, 8, 4, 7, 3]);
pieChart.series = series;

var total = 0;

for(var i = 0; i < values.count(); i++)
	total += values.items()[i];


	
series.supportedLabels = LabelKinds.ToolTip | LabelKinds.OuterLabel;

series.getLabel = function (index, kind)
{
	if (kind == LabelKinds.ToolTip)
		return (values.items()[index]/total * 100).toFixed(2) + " %"; 

if (kind == LabelKinds.OuterLabel)
		return this.outerLabels.items()[index];
	
	return null;
};

//doughnut series, use a renderer
var series1 = new Charting.PieSeries([23, 14, 34], ["2018", "2017", "2016"]);
var p_renderer = new Charting.PieRenderer();
p_renderer.doughnut = true;
p_renderer.series = series1;

pieChart.plot.seriesRenderers.add(p_renderer);

//styling the doughnut series
var brushes1 = new Collections.List([
	new Drawing.Brush("#F24162"),
	new Drawing.Brush("#4B7DBF"),
	new Drawing.Brush("#66b273")	
]);
var seriesBrushes1 = new Collections.List();
seriesBrushes1.add(brushes1);
var strokes1 = new Collections.List([
	new Drawing.Brush("#ffffff")
]);
var seriesStrokes1 = new Collections.List();
seriesStrokes1.add(strokes1);

 var thicknesses1 = new Collections.List([
	6.0
]);
var seriesThicknesses1 = new Collections.List();
seriesThicknesses1.add(thicknesses1);

p_renderer.seriesStyle = new Charting.PerElementSeriesStyle(seriesBrushes1, seriesStrokes1, seriesThicknesses1);

//styling the pie series
var brushes = new Collections.List([
	new Drawing.Brush("#f57088"),
	new Drawing.Brush("#f8a0b0"),
	new Drawing.Brush("#fccfd7"),
	new Drawing.Brush("#a1bbde"),
	new Drawing.Brush("#c6d6eb"),		
	new Drawing.Brush("#88c392"),
	new Drawing.Brush("#99cca2"),
	new Drawing.Brush("#aad4b1"),
	new Drawing.Brush("#bbddc1"),
	new Drawing.Brush("#cce5d0")
	
]);
var seriesBrushes = new Collections.List();
seriesBrushes.add(brushes);
var strokes = new Collections.List([
	new Drawing.Brush("#ffffff")
]);
var seriesStrokes = new Collections.List();
seriesStrokes.add(strokes);

 var thicknesses = new Collections.List([
	6.0
]);
var seriesThicknesses = new Collections.List();
seriesThicknesses.add(thicknesses);
pieChart.plot.seriesStyle = new Charting.PerElementSeriesStyle(seriesBrushes, seriesStrokes, seriesThicknesses);
//theme customization
pieChart.theme.highlightStroke = new Drawing.Brush("#000063");
pieChart.theme.dataLabelsFontSize = 12;
pieChart.theme.dataLabelsBrush = new Drawing.Brush("#ffffff");
pieChart.theme.legendBackground = new Drawing.Brush("#035e96");

//legend setup
pieChart.legendRenderer.showSeriesElements = true;
pieChart.legendRenderer.title = "In Mlns. of USD";
pieChart.legendRenderer.titleBrush = new Drawing.Brush("#ffffff");
pieChart.legendRenderer.elementLabelKind = LabelKinds.OuterLabel;
pieChart.showLegend = true;
pieChart.draw();